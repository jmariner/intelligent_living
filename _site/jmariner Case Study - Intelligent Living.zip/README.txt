Everything in this root folder is the site before the HTML pre-processing and is all what I wrote.
Pre-processing was done by Jekyll (used by GitHub, so it's crediable).

The resulting site is in the _site directory. The resulting HTML is sometimes not indented correctly. That was beyond my control.

Products and categories are loaded by Jekyll from JSON files in the _data directory.

HTML Snippets in the _includes directory are "included" throughout the pages.

Each page uses a layout from _layouts; most used "main" which includes the navbar/footer.